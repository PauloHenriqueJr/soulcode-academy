import { Component } from '@angular/core';

@Component({
  selector: 'app-temp-convert',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'Conversor de Temperaturas';
}
