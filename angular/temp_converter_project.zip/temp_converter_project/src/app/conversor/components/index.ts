export * from './conversor.component';
