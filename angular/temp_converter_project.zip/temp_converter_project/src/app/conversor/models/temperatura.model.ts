export interface ITemperatura {
    valor?: number;
    unidade?: 'celsius' |  'kelvin' | 'fahrenheit';
}