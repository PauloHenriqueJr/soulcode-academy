export * from './temperatura.service';
