export * from './footer.component'
